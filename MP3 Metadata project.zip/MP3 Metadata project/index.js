import express from "express";
import axios from "axios";
import bodyParser from "body-parser";

const app = express();
const port = 4000;

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));

const cientID = "5c6b2f4cc14b4cd88231ad7ae0af04e1";
const clientSecret = "eaeb0dcd4d174513840e3a553f65a81c";
const token = "BQDAM-Zg0vEydEvhvQg919Mks97IZMbJLQL9-Xt_hM5XPB8XB2NxQdQEQiOgCAMBzScfNBiT3vv6Uo3j5VRKD26dQkvGc92pvp0QHKBzltKYW8cBm23teR6vs5_UIXnTdHPNGTLj6Vc"

const trackName = "savior";
const API_URL = "https://api.spotify.com/v1/search?q=" + trackName + "&type=track";


const response = await axios.get(API_URL, {
  headers: {
    Authorization: `Bearer ` + token,
  }
});

app.get("/", (req, res) => {
  res.render("index.ejs", { content: "Waiting for data..." });
});

app.get("/bearerToken", async (req, res) => {
  try{
    response;
    res.render("index.ejs", { content: JSON.stringify(response.data.tracks.items[0].id) });
  }catch (error) {
    console.error("Failed to make request:", error.message);
    res.render("index.ejs", {
      content: "",
      error: error.message,
    });
  }
});

var trackID = response.data.tracks.items[0].id;

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
